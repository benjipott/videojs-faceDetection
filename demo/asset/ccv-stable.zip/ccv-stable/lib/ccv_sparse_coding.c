#include "ccv.h"
#include "ccv_internal.h"

void ccv_sparse_coding(ccv_matrix_t* x, int k, ccv_matrix_t** A, int typeA, ccv_matrix_t** y, int typey)
{
}
